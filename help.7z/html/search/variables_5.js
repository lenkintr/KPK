var searchData=
[
  ['sky',['sky',['../structcolor.html#a9c27a0d5d5420b2cafc2ce18c4eac856',1,'color']]]
];
