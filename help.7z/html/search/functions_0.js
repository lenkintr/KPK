var searchData=
[
  ['becomes_5fdark',['Becomes_Dark',['../_t_x_m___lib_8cpp.html#a60e97f6b5584852019464d7787efaad1',1,'TXM_Lib.cpp']]]
];
