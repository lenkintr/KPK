var searchData=
[
  ['hedgx',['hedgX',['../structcolor.html#afa2c33bbb8c0a7fb6e1a9351c530884a',1,'color']]]
];
